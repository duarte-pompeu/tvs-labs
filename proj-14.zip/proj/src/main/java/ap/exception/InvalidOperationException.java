package ap.exception;

public class InvalidOperationException extends Exception{
	
}
